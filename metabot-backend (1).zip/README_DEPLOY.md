# Meta-Bot Backend (minimal / mock)

Conteúdo:
- server.js             -> servidor Express com rota POST /ask
- adapters/mockAdapter.js -> respostas simuladas (funciona sem chaves)
- fusion.js             -> módulo simples que combina respostas
- db.js                 -> SQLite para log dos pedidos
- package.json          -> dependências e start script

## Rodar localmente (Windows / Linux / Android Termux)
1. Extraia o ZIP para uma pasta, por exemplo: ~/meu-backend
2. Abra o terminal e vá para a pasta
   cd ~/meu-backend
3. Instale dependências:
   npm install
4. Inicie o servidor:
   npm start
5. Abra no navegador ou use curl:
   http://localhost:3000/
   curl -X POST http://localhost:3000/ask -H "Content-Type: application/json" -d '{"question":"Oi"}'

## Deploy rápido (Railway / Render)
- Crie um repositório no GitHub com estes arquivos.
- No Railway: New Project -> Deploy from GitHub -> conecte o repositório.
- Build Command: npm install
- Start Command: npm start
- Adicione variáveis de ambiente se implementar adaptadores reais.

## Como adicionar um provedor real
- Implemente um adapter em /adapters, por exemplo openaiAdapter.js
- No server.js importe e chame o adapter no array de Promise.all
- Guarde as chaves em variáveis de ambiente (.env) no serviço de hospedagem

## Observações
- Este backend é um ponto de partida. A fusão de respostas (fusion.js) é propositalmente simples.
- Para fusões avançadas use um LLM como "editor" (OpenAI/Gemini) chamando-o dentro de fusion.js.

Boa sorte! Se quiser, eu posso gerar o repositório GitHub pronto e até guiar o deploy passo a passo no Railway.