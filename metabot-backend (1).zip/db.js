// Minimal SQLite logger for interactions.
// Creates a file metabot.sqlite in the project root.
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const DB_PATH = path.join(__dirname, 'metabot.sqlite');
const db = new sqlite3.Database(DB_PATH);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS interactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT,
    responses_json TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  )`);
});

function saveInteraction({ question, responses }) {
  return new Promise((resolve, reject) => {
    const stmt = db.prepare("INSERT INTO interactions (question, responses_json) VALUES (?, ?)");
    stmt.run(question, JSON.stringify(responses, null, 2), function(err) {
      if (err) return reject(err);
      resolve(this.lastID);
    });
  });
}

module.exports = { saveInteraction };