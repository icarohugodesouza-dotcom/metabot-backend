// Simple fusion module that combines multiple responses into one.
// This is a starting point — replace with a smarter LLM-based fusion later.
function fuseResponses(question, responses) {
  // Heuristic: prefer longer answers, remove duplicates, and produce a short synthesis.
  const uniqueTexts = Array.from(new Set(responses.map(r => r.text)));
  // Build a synthesis header
  let synthesis = `Síntese Meta-Bot para a pergunta: "${question}"\n\n`;
  // Add short bullets extracted from each response
  uniqueTexts.forEach((t, i) => {
    synthesis += `Fonte ${i+1}: ${t.split('\\n')[0]}...\n`;
  });
  synthesis += `\nResposta final (fusão):\n`;
  // Simple fusion: concatenate first sentences of each unique response
  const parts = uniqueTexts.map(t => t.split('\\n')[0]);
  synthesis += parts.join(' / ');
  return synthesis;
}

module.exports = { fuseResponses };