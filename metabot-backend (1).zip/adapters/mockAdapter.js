// Mock adapter - returns deterministic sample responses quickly.
// Useful for testing without API keys.
module.exports = {
  async respond(question, opts = {}) {
    const model = opts.modelName || 'Mock';
    // Create three simple variant styles
    const base = `Resposta do ${model} para: "${question}"`;
    return {
      model,
      text: `${base}\n\nResumo curto: Este é um mock que demonstra o fluxo.`,
      timestamp: new Date().toISOString()
    };
  }
};