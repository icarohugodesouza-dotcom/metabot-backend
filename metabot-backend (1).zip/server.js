// Simple Meta-Bot backend (Node.js + Express)
// Minimal, comment-heavy, ready to test and deploy.
// Uses a mock adapter by default so it runs without API keys.

const express = require('express');
const cors = require('cors');
const path = require('path');

const mockAdapter = require('./adapters/mockAdapter');
const fusion = require('./fusion');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

// Basic healthcheck
app.get('/', (req, res) => {
  res.send({ ok: true, name: "Meta-Bot Backend (mock)" });
});

// Main route: receives { question: "..." }
app.post('/ask', async (req, res) => {
  try {
    const question = (req.body.question || "").toString().trim();
    if (!question) return res.status(400).json({ error: 'Pergunta vazia' });

    // Collect responses from multiple adapters (here: mock + generic placeholder)
    // You can add more adapters in /adapters and call them here.
    const responses = await Promise.all([
      mockAdapter.respond(question, { modelName: 'Mock-A' }),
      mockAdapter.respond(question, { modelName: 'Mock-B' }),
      mockAdapter.respond(question, { modelName: 'Mock-C' })
    ]);

    // Save to DB (basic logging)
    const recordId = db.saveInteraction({ question, responses });

    // Fuse the responses into a unique final answer
    const answer = fusion.fuseResponses(question, responses);

    res.json({ id: recordId, question, answer, responses });
  } catch (err) {
    console.error('Erro /ask:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Serve a simple static README if requested
app.get('/readme', (req, res) => {
  res.sendFile(path.join(__dirname, 'README_API.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Meta-Bot backend rodando na porta ${PORT}`);
});